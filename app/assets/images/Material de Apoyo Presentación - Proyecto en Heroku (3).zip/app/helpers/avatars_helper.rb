module AvatarsHelper
end
