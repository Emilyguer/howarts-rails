class Image < ApplicationRecord
end
